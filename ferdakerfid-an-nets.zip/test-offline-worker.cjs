const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const scope='https://example.test/trip-app/',handlers={},cacheData=new Map(),cacheNames=new Map();let online=true,fetches=[],claimed=false,skipped=false;
function cache(name){if(!cacheNames.has(name))cacheNames.set(name,new Map());const values=cacheNames.get(name);return {put:async(k,v)=>values.set(k,v),match:async k=>values.get(k)?.clone()}}
const self={registration:{scope},addEventListener:(name,fn)=>handlers[name]=fn,clients:{claim:async()=>claimed=true},skipWaiting:async()=>skipped=true};
const ctx=vm.createContext({self,URL,Response,AbortController,setTimeout,clearTimeout,caches:{open:async name=>cache(name),keys:async()=>[...cacheNames.keys()],delete:async name=>cacheNames.delete(name)},fetch:async request=>{fetches.push(typeof request==='string'?request:request.url);if(!online)throw new Error('Network unavailable');return new Response('asset:'+(typeof request==='string'?request:request.url),{status:200})}});vm.runInContext(fs.readFileSync(__dirname+'/sw.js','utf8'),ctx);
function waitEvent(name,extra={}){let pending;handlers[name]({...extra,waitUntil:p=>pending=p});return pending}
async function request(path,mode='navigate',method='GET'){let answer;handlers.fetch({request:{url:new URL(path,scope).href,mode,method},respondWith:p=>answer=p});return answer?await answer:undefined}
(async()=>{
 await waitEvent('install');assert(skipped);assert.equal(fetches.length,3);await waitEvent('activate');assert(claimed);
 let readiness;await waitEvent('message',{data:{type:'CHECK_OFFLINE_SHELL'},ports:[{postMessage:v=>readiness=v.ready}]});assert.equal(readiness,true);
 online=false;fetches=[];const cold=await request('./');assert((await cold.text()).includes('offline.html'));const index=await request('index.html?trip=abc');assert((await index.text()).includes('offline.html'));
 const js=await request('offline.js','cors');assert((await js.text()).includes('offline.js'));assert.equal(fetches.length,2); // navigation attempted; UI asset never needed the network
 assert.equal(await request('/another-app/'),undefined);assert.equal(await request('https://private.example.test/storage/doc.pdf','cors'),undefined);assert.equal(await request('./','navigate','POST'),undefined);
 online=true;const live=await request('./');assert.equal(await live.text(),'asset:'+scope);
 // A missing asset prevents install from succeeding, rather than claiming readiness.
 ctx.fetch=async()=>new Response('Not found',{status:404});await assert.rejects(()=>waitEvent('install'),/Missing offline asset/);
 console.log('PASS: shell installation/readiness, cold offline navigation, cached dependency-free UI, online navigation, no API/document/other-site interception, failed install handling.');
})().catch(e=>{console.error(e);process.exitCode=1});
