const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/index.html','utf8');
class Node{
 constructor(id=''){this.id=id;this.value='';this.innerHTML='';this.textContent='';this.dataset={};this.checked=false;this.disabled=false;this.style={setProperty(){}};this.classes=new Set();this.classList={add:(...s)=>s.forEach(x=>this.classes.add(x)),remove:(...s)=>s.forEach(x=>this.classes.delete(x)),contains:s=>this.classes.has(s),toggle:(s,on)=>{on=on??!this.classes.has(s);on?this.classes.add(s):this.classes.delete(s);return on}}}
 querySelectorAll(){return []}querySelector(){return new Node()}closest(){return new Node()}addEventListener(){}removeAttribute(){}setAttribute(){}scrollIntoView(){}focus(){}select(){}
}
const nodes=new Map([...html.matchAll(/\bid="([^"]+)"/g)].map(m=>[m[1],new Node(m[1])]));
const getNode=id=>{if(!nodes.has(id))nodes.set(id,new Node(id));return nodes.get(id)};
const store=new Map(),saved=[],db={};
const client={from(table){const q={select(){return q},order(){return q},eq(k,v){q.filter??={};q.filter[k]=v;return q},insert(p){q.payload=p;q.inserted=true;return q},update(p){q.payload=p;return q},async single(){const id=q.filter?.id||'new-item',prev=(db[table]||[]).find(x=>x.id===id)||{};const data={...prev,...q.payload,id};saved.push({table,payload:structuredClone(data)});db[table]=[...(db[table]||[]).filter(x=>x.id!==id),data];return {data,error:null}},then(resolve){resolve({data:db[table]||[],error:null})}};return q}};
const fixed=Date.parse('2026-06-11T08:00:00Z');class TestDate extends Date{constructor(...args){super(...(args.length?args:[fixed]))}static now(){return fixed}}
const ctx=vm.createContext({console,Intl,Date:TestDate,Map,Set,Object,Number,Math,JSON,Promise,Error,Array,String,RegExp,URL,URLSearchParams,structuredClone,createClient:()=>client,maplibregl:{},setInterval(){},setTimeout(){},clearTimeout(){},requestAnimationFrame:f=>f(),document:{hidden:false,getElementById:getNode,querySelectorAll:()=>[],addEventListener(){}},window:{confirm:()=>true,scrollTo(){}},localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)},db,saved,assert});
let script=html.match(/<script type="module">([\s\S]*?)<\/script>/)[1].replace(/^import .*;$/gm,'').replace(/\ninit\(\);/,'\n').replace(/\ninitAirportFields\(\);/,'\n');vm.runInContext(script,ctx);
const run=s=>vm.runInContext(s,ctx);
(async()=>{
run(`state.user={id:'user'};state.trip={id:'trip',name:'Ítalía',start_date:'2026-06-05',end_date:'2026-06-23',timezone:'Europe/Rome',status:'planning'};
state.stops=[{id:'napoli',name:'Napólí',start_date:'2026-06-05',end_date:'2026-06-06',timezone:'Europe/Rome',country_code:'IT'},{id:'rome',name:'Róm',start_date:'2026-06-06',end_date:'2026-06-11',timezone:'Europe/Rome',country_code:'IT'},{id:'sorrento',name:'Sorrento',start_date:'2026-06-11',end_date:'2026-06-16',timezone:'Europe/Rome',country_code:'IT'}];
state.items=[{id:'train',trip_id:'trip',category:'train',title:'Lest suður',status:'open',local_date:null,local_time:null,metadata:{unrelated:'keep',route_plan:{from_stop_id:'rome',to_stop_id:'sorrento'}}}];state.expenses=[];state.walletDocs=[];state.notes=[];`);
assert.equal(run('tripTodayDate()'),'2026-06-11');assert.equal(run('tripInProgress()'),true);
run('renderTimeline()');let timeline=getNode('timeline').innerHTML;assert(timeline.indexOf('data-stop="rome"')<timeline.indexOf('data-route-item="train"'));assert(timeline.indexOf('data-route-item="train"')<timeline.indexOf('data-stop="sorrento"'));assert(timeline.includes('Áætlað'));assert.equal(run('state.items[0].local_date'),null);
assert.equal(run("openJourneyRelevant(state.items[0],'2026-06-11')"),true);assert.equal(run("openJourneyRelevant(state.items[0],'2026-06-12')"),false);
run("$('itemCategory').value='train';$('itemStatus').value='open';fillOpenJourneyForm(state.items[0].metadata.route_plan)");assert.equal(getNode('openJourneyFrom').value,'rome');assert.equal(getNode('openJourneyTo').value,'sorrento');
assert.equal(run('readOpenJourneyPlan(state.items[0]).from_stop_id'),'rome');
run("$('openJourneyStart').value='2026-06-12';$('openJourneyEnd').value='2026-06-14'");assert.equal(run('readOpenJourneyPlan().end_date'),'2026-06-14');
assert.throws(()=>run("$('openJourneyEnd').value='2026-06-10';readOpenJourneyPlan()"),/Lok áætlaðs/);
assert.throws(()=>run("$('openJourneyStart').value='2026-07-01';$('openJourneyEnd').value='';readOpenJourneyPlan()"),/innan ferðadaganna/);
assert.throws(()=>run("$('openJourneyStart').value='';$('openJourneyTo').value='missing';readOpenJourneyPlan()"),/fannst ekki/);
run("fillOpenJourneyForm(state.items[0].metadata.route_plan)");
// Actual form saving and loading are exercised; unrelated map/weather form work is isolated.
run(`updateFlightFields=()=>{};refreshStopSelect=()=>{};paintLodgingLocation=()=>{};updateGoogleMapsLinkPreview=()=>{};restoreCancellationForm=()=>{};restoreDeparturePlanForm=()=>{};updateFerryVehicleFields=()=>{};restoreBookingPlace=()=>{};updateItemPaymentControls=()=>{};paintLinkedQuickCosts=()=>{};resetBookingDateActions=()=>{};
validateBookingTravelDates=()=>true;readGoogleMapsLink=()=>null;readTransportCityPlaces=()=>({});syncTransportDates=()=>{};readDeparturePlans=()=>null;readCancellationForm=()=>({mode:'none'});confirmBookingDates=()=>true;clearItemForm=()=>{};renderTrip=()=>{};refreshTransportCityMap=()=>{};
state.tripLoadError=false;db.trip_items=structuredClone(state.items);saveExpenseForItem=async()=>({error:null});
openEditItem('train');$('itemTitle').value='Lest Róm → Napólí';$('itemWeatherExposure').value='auto';`);
await run('saveItem()');assert.equal(saved.length,1);assert.equal(saved[0].payload.id,'train');assert.equal(saved[0].payload.local_date,null);assert.equal(saved[0].payload.local_time,null);assert.equal(saved[0].payload.metadata.route_plan.from_stop_id,'rome');assert.equal(saved[0].payload.metadata.unrelated,'keep');
run("openEditItem('train')");assert.equal(getNode('openJourneyFrom').value,'rome');assert.equal(getNode('openJourneyTo').value,'sorrento');
run("$('itemStatus').value='booked';$('outboundFrom').value='Roma Termini';$('outboundTo').value='Napoli Centrale';$('outboundDepartureDate').value='2026-06-11';$('outboundDepartureTime').value='11:00'");await run('saveItem()');assert.equal(saved.length,2);assert.equal(saved[1].payload.id,'train');assert.equal(saved[1].payload.status,'booked');assert.equal(saved[1].payload.local_date,'2026-06-11');assert.equal(saved[1].payload.metadata.route_plan.from_stop_id,'rome');assert.equal(run("openJourneyRelevant(state.items[0],'2026-06-11')"),false);
run(`state.items=[{id:'bike',title:'Hjólaferð',category:'bike_tour',status:'booked',stop_id:'rome',local_date:'2026-06-11',local_time:'11:00',metadata:{departure_plans:{outbound:{enabled:true,timezone:'Europe/Rome',origin:'Hótel',destination:'Hjólamiðstöð',mode:'walking',travel_minutes:20,arrival_minutes:15,buffer_minutes:10}}}},{id:'coffee',title:'Kaffi',category:'cafe',status:'booked',local_date:'2026-06-11',local_time:'10:30',metadata:{quick_cost:true}},{id:'old',title:'Fyrra atriði',category:'bike_tour',status:'booked',local_date:'2026-06-11',local_time:'09:00'}];state.walletDocs=[{id:'ticket1',item_id:'bike',title:'Miði Kristjáns'},{id:'ticket2',item_id:'bike',title:'Miði eiginkonu'}];`);
assert.equal(run('nextTodayEntry().item.id'),'bike');run('renderToday()');assert(getNode('todayNext').innerHTML.includes('Hjólaferð'));assert(getNode('todayItems').innerHTML.includes('Hjólaferð'));const next=run("nextTodayHtml('2026-06-11')");assert(next.includes('Leggðu af stað kl. 10:15'));assert(next.includes('Mættu kl. 10:45'));assert(next.includes('data-next-document="ticket1"'));assert(next.includes('data-next-document="ticket2"'));assert(next.includes('Gönguleið'));
run(`state.items=[{id:'round',title:'Flug',category:'flight',status:'booked',local_date:'2026-06-05',local_time:'18:00',metadata:{transport_trip_type:'round_trip',return_date:'2026-06-11',return_time:'12:00',return_booking_reference:'HOME123'}}]`);assert.equal(run('nextTodayEntry().leg'),'return');assert(run("nextTodayHtml('2026-06-11')").includes('HOME123'));
run(`state.trip.timezone='';state.stops=[]`);assert.equal(run('nextTodayEntry()'),null);
run(`state.trip.timezone='Europe/Rome';state.items=[{id:'midnight',title:'Flug um nótt',category:'flight',status:'booked',local_date:'2026-06-12',local_time:'00:15',metadata:{departure_plans:{outbound:{enabled:true,timezone:'Europe/Rome',origin:'Hótel',destination:'Flugvöllur',mode:'driving',travel_minutes:60,arrival_minutes:90,buffer_minutes:15}}}}]`);assert(run("nextTodayHtml('2026-06-11')").includes('Leggðu af stað kl. 21:30'));
// Fresh full context tests initial view selection with fetch results and unrelated renderers isolated.
run(`state.trips=[state.trip];db.trip_stops=[];db.trip_items=[];db.expenses=[];db.trip_notes=[];db.wallet_documents=[];state.items=[];refreshFlightMonitoring=()=>{};renderToday=()=>{};renderCalendar=()=>{};`);
await run("openTrip('trip')");assert.equal(getNode('todayView').classList.contains('hidden'),false);assert.equal(getNode('routeView').classList.contains('hidden'),true);assert.equal(run('state.selectedDate'),'2026-06-11');
run("state.trips[0].start_date='2027-06-05';state.trips[0].end_date='2027-06-23'");await run("openTrip('trip')");assert.equal(getNode('routeView').classList.contains('hidden'),false);assert.equal(getNode('todayView').classList.contains('hidden'),true);assert.equal(run('state.selectedDate'),'2027-06-05');
run("state.trips[0].start_date='2025-06-05';state.trips[0].end_date='2025-06-23'");await run("openTrip('trip')");assert.equal(getNode('routeView').classList.contains('hidden'),false);

// Reproduce the screenshot: Copenhagen 15–18, return flight 18, Haag 19–20,
// legacy open train has route names but no new route_plan metadata.
run(`state.trip={id:'oct',name:'Prufuferð',start_date:'2026-10-15',end_date:'2026-10-20',timezone:'Europe/Copenhagen'};
state.stops=[{id:'cph',name:'Kaupmannahöfn',country_code:'DK',start_date:'2026-10-15',end_date:'2026-10-18'},{id:'haag',name:'Haag',country_code:'NL',start_date:'2026-10-19',end_date:'2026-10-20'}];
state.items=[{id:'flight-oct',trip_id:'oct',category:'flight',title:'Icelandair',status:'booked',local_date:'2026-10-15',local_time:'07:40',metadata:{transport_trip_type:'round_trip',outbound_from:'KEF',outbound_to:'CPH',outbound_departure_date:'2026-10-15',outbound_departure_time:'07:40',return_from:'CPH',return_to:'KEF',return_date:'2026-10-18',return_time:'14:00'}},{id:'legacy-train',category:'train',title:'Lest',status:'open',local_date:null,local_time:null,metadata:{outbound_from:'Kaupmannahöfn',outbound_to:'Haag'}}];`);
assert.equal(run('timelineDateWarnings().length'),1);
assert.equal(run("timelineDateWarnings()[0].kind"),'return-before-stop');
run('renderTimeline()');assert(getNode('timelineDateWarnings').innerHTML.includes('Haag'));assert(getNode('timelineDateWarnings').innerHTML.includes('Icelandair'));assert.equal(getNode('timelineDateWarnings').classList.contains('hidden'),false);
let legacyTimeline=getNode('timeline').innerHTML;
assert(legacyTimeline.indexOf('data-stop="cph"')<legacyTimeline.indexOf('data-route-item="legacy-train"'));
assert(legacyTimeline.indexOf('data-route-item="legacy-train"')<legacyTimeline.indexOf('data-stop="haag"'));
assert.equal(run('state.items[1].local_date'),null);assert.equal(run('state.items[1].metadata.route_plan'),undefined);
assert.equal(run("openJourneyRelevant(state.items[1],'2026-10-18')"),true);assert.equal(run("openJourneyRelevant(state.items[1],'2026-10-19')"),true);
assert.equal(run("openJourneyRelevant(state.items[1],'2026-10-20')"),false);
// Repeated city stays must never be silently conflated.
run("state.stops.push({...state.stops[0],id:'cph-again',start_date:'2026-10-20',end_date:'2026-10-20'})");assert.equal(run("matchingJourneyStop(state.items[1],'outbound_from')"),null);run("state.stops.pop()");
// Correcting return flight removes warning without moving dates.
run("state.items[0].metadata.return_date='2026-10-20'");assert.equal(run('timelineDateWarnings().length'),0);run('renderTimelineDateWarnings()');assert(getNode('timelineDateWarnings').classList.contains('hidden'));
// Real booking save: a new return-before-stop conflict can be declined before any write.
run("openEditItem('flight-oct');$('returnFlightDate').value='2026-10-18';window.confirm=message=>{globalThis.lastConfirm=message;return false}");
const before=saved.length;await run('saveItem()');assert.equal(saved.length,before);assert(run('lastConfirm').includes('Haag'));assert.equal(run('state.items[0].metadata.return_date'),'2026-10-20');
// Accepting the exception is explicit and the warning persists afterwards.
run('window.confirm=()=>true');await run('saveItem()');assert.equal(saved.length,before+1);assert.equal(saved.at(-1).payload.metadata.return_date,'2026-10-18');assert.equal(run('timelineDateWarnings().length'),1);
// Existing, unchanged conflicts do not trigger a repeated save confirmation.
run("window.confirm=()=>{throw new Error('Unexpected repeated confirmation')}");assert.equal(run('confirmNewTimelineWarnings()'),true);
// Stop creation is protected too, rather than only editing the flight.
run("globalThis.savedStops=state.stops;state.stops=[state.stops[0]];state.editingStopId=null;state.stopPlaceSelection=null;$('stopName').value='Haag';$('stopStart').value='2026-10-19';$('stopEnd').value='2026-10-20';$('stopCountry').value='NL';$('stopLat').value='';$('stopLng').value='';window.confirm=()=>false");
const beforeStop=saved.length;await run('saveStop()');assert.equal(saved.length,beforeStop);assert.equal(run('state.stops.length'),1);run('state.stops=savedStops');
// Existing dates outside the overall trip remain visible too.
run("state.trip.end_date='2026-10-18'");assert(run("timelineDateWarnings().some(w=>w.key==='stop-range:haag')"));
console.log('PASS: screenshot conflict, persistent warning, legacy train ordering, inferred date range, ambiguous cities, rejected/accepted real flight save, unchanged conflict, trip-boundary warning.');
console.log('PASS: timeline context, date ranges, validation, save/reopen/update same item, unrelated metadata, today time/return flight/midnight, both tickets, and initial views for current/future/past trips.');
})().catch(e=>{console.error(e);process.exitCode=1});
