const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const {IDBFactory,IDBObjectStore}=require('fake-indexeddb');
const indexedDB=new IDBFactory();
function context(path='/trip-app/'){const ctx=vm.createContext({indexedDB,URL,location:{href:'https://example.test'+path},Event,console,localStorage:{setItem(){}},dispatchEvent(){}});vm.runInContext(fs.readFileSync(__dirname+'/offline-store.js','utf8'),ctx);return ctx.OfflineTravel}
(async()=>{
 const store=context();await store.activate('user-a');
 const pack={trip:{id:'rome',name:'Ítalía'},stops:[],items:[],notes:[],wallet:[],savedAt:'2026-10-17T19:00:00Z',documents:[{id:'ticket',title:'Flugmiði',available:true,blob:new Blob(['private-pdf'],{type:'application/pdf'})},{id:'external',title:'Vefslóð',available:false}]};
 await store.replace('user-a',pack);
 // A new JS execution context reads the same stored bytes, with no network/auth.
 const restarted=context(),copy=await restarted.read('user-a','rome');assert.equal(await copy.documents[0].blob.text(),'private-pdf');assert.equal(copy.savedAt,pack.savedAt);const list=await restarted.list('user-a');assert.equal(list[0].documents[0].blob,undefined);assert.equal(list[0].documents[0].available,true);
 await assert.rejects(()=>restarted.read('user-b','rome'),/Innskráning/);
 const otherSite=context('/another-app/');assert.equal(await otherSite.owner(),null);
 // Inject a real IDB transaction failure; an old package must stay intact.
 const originalPut=IDBObjectStore.prototype.put;IDBObjectStore.prototype.put=function(value,...args){if(this.name==='trips')throw new DOMException('Device full','QuotaExceededError');return originalPut.call(this,value,...args)};
 await assert.rejects(()=>store.replace('user-a',{...pack,savedAt:'new'}),e=>e.name==='QuotaExceededError');IDBObjectStore.prototype.put=originalPut;assert.equal((await store.read('user-a','rome')).savedAt,pack.savedAt);assert.equal(await (await store.read('user-a','rome')).documents[0].blob.text(),'private-pdf');
 // Refresh replaces one package rather than accumulating duplicate trips/files.
 await store.replace('user-a',{...pack,savedAt:'updated',documents:[{id:'new',available:true,text:'Bókunarnúmer 123'}]});assert.equal((await store.list('user-a')).length,1);assert.equal((await store.read('user-a','rome')).documents.length,1);
 await store.remove('user-a','rome');assert.equal(await store.read('user-a','rome'),null);
 await store.replace('user-a',pack);await store.activate('user-b');assert.equal((await store.list('user-b')).length,0);await assert.rejects(()=>store.replace('user-a',pack),/Innskráning/); // late in-flight save after account switch
 await store.replace('user-b',pack);await store.clear();assert.equal(await store.owner(),null);await store.activate('user-b');assert.equal((await store.list('user-b')).length,0);
 console.log('PASS: IndexedDB Blob round-trip across reload, owner/site isolation, atomic rollback on quota error, refresh without duplicates, removal, sign-out clear, rejection of late account write.');
})().catch(e=>{console.error(e);process.exitCode=1});
