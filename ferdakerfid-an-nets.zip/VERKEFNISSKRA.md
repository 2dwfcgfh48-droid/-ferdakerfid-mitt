# Ferðakerfið mitt — gildandi verkefnisskrá

## Nýjasta afhending — ferð og miðar án nets, 17. október 2026

Grunnur: `skjol-skyrari-adgerdir/index.html`. Allar fyrri ákvarðanir halda gildi nema nýrri samþykki hér breyti þeim. Nýjasta afhending er þessi mappa.

### Samþykkt og útfært

- „Sækja fyrir ferð“ við opna ferð vistar lesafrit af dagskrá, áfangastöðum, bókunarnúmerum, skráðum heimilisföngum, athugasemdum og skráðum brottfararáætlunum. Notandi velur hvaða skjöl/miða á að sækja með.
- „Ferðir án nets“ er á forsíðu og „Opna sótt afrit“ við ferð. Innskráningarskjár hefur líka beina leið í sóttar ferðir, óháða netbundnum forritssöfnum.
- Sótt afrit hefur sjálfstæðan lesara sem þarf ekki nýja innskráningu, Supabase, CDN, kortasafn eða útrunna aðgangsslóð. Við ræsingu án nets skilar þjónustuvinnsla (service worker) þessum lesara í stað netbundna aðalappsins.
- Fimm vefskrár þurfa að liggja saman á sömu HTTPS-slóð: `index.html`, `offline.html`, `offline.js`, `offline-store.js`, `sw.js`. Eina HTML-skráin nægir ekki lengur. Gildissvið þjónustuvinnslunnar er mappa appsins, líka á GitHub Pages undirslóð.
- Lesarinn geymir ferðaleið, dagatal og allar bókanir. Nauðsynleg herbergi eru áfram í dagskrá; varabókanir/afbókuð gisting sjást merkt í öllum bókunum. Áætlaðar opnar samgöngur halda áætluðum dögum án þess að breyta raunverulegum brottfarardegi.
- Báðir flugmiðar hjóna, eða fleiri skjöl, hafa sjálfstæða opnun. Skjöl opnast í skoðara með „Loka skjali“, þysjun mynda og deilingu þegar vafrinn styður það. PDF-birting byggir áfram á PDF-stuðningi vafrans. Önnur snið má hlaða niður eða opna í öðrum flipa undir „Fleiri aðgerðir“.
- Staða sýnir nákvæmlega hvaða skjöl voru sótt, hvað var ekki valið og hvaða vefslóðir þurfa net. Vistaður texti má fylgja; almennar vefsíður eru ekki þykjast vistaðar sem miðar.
- Uppfærslutími er alltaf sýnilegur. Breyting á ferð sem er opin í aðalappinu merkir sótta afritið til uppfærslu; notandi sækir aftur. Lesafrit breytir ekki netgögnum og býður ekki upp á breytingar án nets/samstillingarröð.
- Sókn er staðfest eftir ræsifærni lesarans og vistun. Valdar skrár eru sóttar í heilu lagi áður en nýtt afrit kemur í stað eldra. Sóknarvilla, of lítið rými eða stöðvun heldur fyrra afriti óbreyttu. Stöðva má sókn; aðeins sjálf vistunarfærslan er óstöðvanleg meðan hún lýkur. Hámark valinna viðhengja er 100 MB á ferð.
- Afrit eru í IndexedDB í sama tæki/vafra. Þau eru afmörkuð við innskráðan notanda og slóð appsins. Reikningsskipti og útskráning hreinsa sótt afrit; síðbúin vistun fyrri notanda er hafnað. Eyðing ferðar reynir einnig að hreinsa sótta afritið. Hægt er að fjarlægja lesafrit úr tækinu án þess að eyða ferð á netinu.
- Þjónustuvinnslan geymir einungis opinberar lesaraskrár, ekki þjónustuköll, auðkenni eða einkaskjöl. Aðgangsslóðir/jwt eru ekki nauðsynleg til enduropnunar skráa án nets.
- Kort, nettengd leiðsögn, nýjustu flug-/veðurupplýsingar og ytri vefsíður þurfa áfram net. Notandi fær skýra skýringu. Vafrinn getur fjarlægt staðbundin gögn við rýmiskort eða hreinsun; reynt er að biðja um varanlega geymslu en henni er ekki lofað.

### Prófað

- JavaScript-setningafræði allra skripta, einstök HTML-auðkenni og tilvist allra vefskráa.
- Fyrri `test-flow.cjs`, `test-features.cjs`, `test-viewer.cjs` standast.
- `test-offline-store.cjs`: IndexedDB-skrár/Blob í nýju keyrslusamhengi, aðskilnaður notenda og vefslóða, uppfærsla án tvítalningar, höfnun/afturköllun við geymsluvillu, fjarlæging, útskráning og síðbúin vistun fyrri notanda. Notar fake-indexeddb.
- `test-offline-worker.cjs`: uppsetning og staðfesting lesaraskráa, köld netlaus leiðsögn, netlausar fylgiskrár, venjuleg netleiðsögn og afmörkun frá öðrum vefjum og þjónustuköllum. Keyrt í hermdu Service Worker-umhverfi.
- `test-offline-flow.cjs`: raunverulegar aðgerðir með DOM-hermi og IndexedDB-hermi. Tveir PDF-miðar, val/ósótt vefslóð, misheppnuð uppfærsla, vantar lesaraskrár, stöðvuð sókn, úrelt afrit, varðveisla óvistaðs innsláttar, nýtt lesarasamhengi án fetch/innskráningar/CDN, heimilisfang, út-/heimleiðarnúmer, varahótel, opin lest með áætluðu dagabili, PDF-opnun/lokun, vistuð skjalabæti úr opnu aðalappi og hreinsun í öðrum flipa. Notar jsdom og fake-indexeddb.
- Engar nýjar þjónustuskrifanir, skemabreytingar eða raunveruleg innskráð skjalasókn voru framkvæmdar. Nýja netlausa flæðið skrifar ekki í ferðagagnagrunn.

### Óstaðfest og næsta yfirferð

- Raunverulegt Safari/iPhone-flughampróf og lifandi þjónustuvinnsla á hýstu HTTPS-vefsvæði eru óstaðfest. Browser-control var ekki tiltækt í þessu umhverfi; enginn forskoðunarþjónn eða raunvafraprófun var keyrð.
- Prófa: setja allar 5 skrár á GitHub; opna á neti; sækja ferð og tvo miða; loka appinu; flughamur; opna sömu vefslóð aftur; skoða ferð og báða miða; prófa PDF með fleiri síðum, þysjun og lokun. Opna svo á neti, breyta bókun, sækja aftur og endurtaka. Prófa fjarlægingu og útskráningu.
- Ekkert var sett á GitHub í þessari vinnulotu. Afhending er skráapakki fyrir sama handvirka upphleðsluflæði og áður.
- Fyrri ólokin verkefni halda gildi, m.a. tilkynningar þegar app er lokað, almenn greining gistináttagata og aðskilnaður daglegra reikninga frá dagskrá.

---

## Nýjasta afhending — skýrari skjalaspjaldsaðgerðir, 17. október 2026

Grunnur: `skjol-loka-og-til-baka/index.html`. Nýjasta HTML er í þessari möppu. Nýrri samþykki gilda framar eldri heitum.

- Notandi staðfesti að deiling í tölvupósti virkar. Þetta staðfestir ekki öll snið eða allar deilileiðir.
- „Opna sér“ heitir nú „Opna í öðrum flipa“ undir „Fleiri aðgerðir“. Valmyndin er lokuð við hverja nýja skjalaskoðun. Skýring segir hvernig er farið aftur í ferðina.
- „Sækja“ heitir „Hlaða niður skjali“. Sýnileg skýring segir að niðurhal sé afrit utan appsins og að fara þurfi til baka í ferðaflipann ef vafrinn opnar afritið sérstaklega.
- Venjuleg opnun og „Loka skjali“ eru óbreytt. Skjalaskoðunin, vistun, deiling og varðveisla bókunarinnsláttar haldast. Ný heiti eru samræmd í leiðbeiningum og villuskilaboðum skoðarans.
- Lyklaborðsfókus tekur aðeins sýnilegar aðgerðir með, ásamt „Fleiri aðgerðir“.
- Setningafræði, einstök HTML-auðkenni og fyrri prufugagnapróf eru yfirfarin í þessari afhendingu. Nýja staðsetningin og textinn eru ekki prófuð í raunverulegum iPhone/vafra. Engin GitHub-uppfærsla framkvæmd.

---

# Ferðakerfið mitt — verkefnisskrá

## Nýjasta afhending — loka skjölum og miðum, 17. október 2026

Grunnur: `gistivalkostir-og-ferdaveski/index.html`. Nýjasta útfærslan er `index.html` í þessari möppu. Eldri kaflar hér fyrir neðan geyma áfram gildandi ákvarðanir og prófunarsögu.

### Samþykkt og útfært

- Sameiginleg skjalaskoðun með alltaf sýnilegum hnappi „Loka skjali“. Ferðaveski, tengdir miðar í Í dag, skjöl í bókunarglugga og við breytingu skjals nota sömu aðgerð. Vistaður bókunartexti notar líka skoðarann. Bókunarvefslóðir úr ferðaveski fá sömu umgjörð.
- Undirliggjandi ferð/bókun er ekki endurteiknuð eða lokuð. Reitir, skjalaval og skrun haldast. Fókus færist aftur á fyrri stað þegar lokað er. Bakgrunnur er óvirkur meðan skjal er opið. Escape lokar skoðaranum.
- Myndir hafa þysjunarhnappa og skrun. PDF birtist í innfelldum skoðara; flettingar og þysjun PDF ráðast af stuðningi vafrans. „Opna sér“ er varaleið ef PDF birtist ekki rétt.
- Einkaskjöl nota áfram sömu tímabundnu aðgangsheimild. Skráin er sótt í minni til niðurhals og deilingar þegar það tekst. Þetta er ekki varanleg vistun án nets. Gögn eru ekki skrifuð í gagnagrunn við opnun/lokun.
- „Sækja“ og „Deila“ eru virk eftir getu vafrans og aðgengi skjals. Deiling einkaskráar sendir skrána sjálfa. Venjulegum ytri vefslóðum er deilt sem slóð. Hætt við deilingu birtir ekki villu.
- Önnur snið, t.d. Apple Wallet og HEIC, og almennar vefsíður fá leiðbeiningar og „Opna sér“. Þau eru ekki óvart opnuð í aðalglugga ferðarinnar.
- Lokun eða opnun annars skjals meðan sókn bíður kemur í veg fyrir að gömul niðurstaða yfirskrifi nýjan skoðara.

### Prófanir og takmarkanir

- JavaScript-setningafræði stenst. `test-flow.cjs` og `test-features.cjs` standast áfram.
- `test-viewer.cjs` prófar raunverulegar aðgerðir með hermdu DOM og þjónustuköllum: PDF, mynd, texta, niðurhal, deilingu, þysjun, lokun, óvistaðan innslátt/val/skrun/fókus, ógilda slóð, netvillu og síðbúna sókn eftir skipti um skjal. Aðalglugga er ekki vísað burt.
- Engin vafraprófun var gerð; aðgengileg browser-control leið fyrir þetta umhverfi vantaði. Raunveruleg Safari/iPhone-birting, margra síðna PDF, þysjun, deiling og niðurhal þurfa prófun. Prófa sérstaklega opnun úr óvistaðri bókun og lokun til baka.
- Engin innskráð skjalasókn eða GitHub-uppfærsla var framkvæmd. Afhending er uppfærð HTML-skrá eins og áður.
- Fyrri opin verk halda gildi: tilkynningar þegar app er lokað, notkun ferðaveskis án nets og aðrar óútfærðar úrbætur.

---

# Ferðakerfið mitt — verkefnisskrá

Uppfært 17. október 2026. Viðmið: Sources „Ferðakerfið Mitt - gildandi ákvarðanir“, aðgengilegt samtal og nýrri samþykki notanda. Nýrri skýr fyrirmæli ganga framar eldri ákvörðunum.

## Nýjasta afhending — gistivalkostir og ferðaveski, 17. október 2026

Grunnur: `timalina-dagsetningavorn/index.html`. Þessi mappa geymir nýjustu útfærsluna í `index.html`; eldri afhendingar hér fyrir neðan eru saga og viðmið. Nýrri skýr fyrirmæli notanda ganga framar eldri texta.

### Samþykkt og útfært

- Hnappurinn „Tengja miða / skjal“ er í bókunarglugga allra ferðahluta. Velja má úr ferðaveski eða bæta við nýju skjali. Óvistað heiti, upphæð, dagsetningar, klukka, aðrir reitir og skrunstaða bíða á meðan.
- Tenging skjala er geymd sem óvistuð breyting þar til bókun er vistuð. Nýtt skjal getur vistast sjálfstætt í ferðaveskið á meðan; hætt sé við bókun tapast það ekki og verður áfram ótengt. Fyrirliggjandi skjal sem tilheyrir annarri bókun er ekki tekið sjálfkrafa yfir.
- Skjöl má tengja eða aftengja við breytingu eldri bókunar. Aftenging eyðir ekki skjalinu. Innflutningur bókunar heldur upprunalegri staðfestingu.
- Ef bókun og kostnaður vistast en tenging skjals bregst heldur glugginn auðkenni vistuðu bókunarinnar. Endurtilraun uppfærir sömu færslu og tengingar sem þegar vistuðust eru ekki tvíteknar. Samhliða breytt skjalatenging er varin með skilyrði á fyrri tengingu.
- Við skarandi gistidaga á sama áfangastað er spurt hvort bæði herbergin séu nauðsynleg eða þetta séu gistivalkostir. Samnefnd borg með sama landi í tveimur áfangastaðafærslum er einnig greind. Gistinótt við útritun er ekki talin skörun við nýja innritun sama dag.
- Nauðsynleg viðbótarherbergi, t.d. fyrir börnin, teljast með ferðakostnaði. Þau eru ekki sjálfkrafa varabókanir.
- Valkostur tengist upprunalegri gistibókun. Fyrsta bókunin er valin í bili nema notandi velji annan valkost. Val geymist á upprunalegu bókuninni og er uppfært með einni vistun. Skipt er um gistingu í yfirlitinu „Gistivalkostir“.
- Valin gisting og nauðsynleg viðbótarherbergi teljast í heildaráætlun. Aðrar virkar bókanir eru sýndar sér sem skuldbindingar, með bókunarverði, greiðslum og ógreiddum eftirstöðvum. Val afbókar engar aðrar bókanir hjá söluaðila.
- Ef skörun eldri bókana er óflokkuð eða enginn virkur valkostur er valinn er heildaráætlun merkt ófullgerð. Skarandi en mislanga valkosti þarf að yfirfara; dagsetningum er ekki breytt sjálfkrafa.
- Greiðslufrestur og frestur ókeypis afbókunar eru aðskilin. Afbókunarfrestir haldast sjálfstæðir fyrir allar virkar bókanir, líka varabókanir. Gjalddagar ógreiddra gistibókana birtast í áminningum þegar sjö dagar eða minna eru eftir, bæði innan ferðar og á forsíðu. Afbókunarfrestur sem vantar er sýndur sem óskráður.
- „Afbókað hjá söluaðila“ krefst þess að notandi staðfesti að hann hafi sjálfur afbókað. Appið framkvæmir enga afbókun. Bókun, skjöl, upprunalegt verð og greiðslur varðveitast.
- Afbókunargjald og móttekin endurgreiðsla eru skráð sér í mynt bókunarinnar. Aðeins gjaldið telst ferðakostnaður; endurgreiðsla eyðir ekki upprunalegri greiðslu. Ómóttekinn endurgreiðsluhluti er sýndur. Greiðslur mega ekki verða lægri en þegar skráð móttekin endurgreiðsla.
- Heildaráætlun er samræmd í ferð, kostnaðaryfirliti, forsíðu, farnar-ferðir-yfirliti og PDF. Reikningur fyrir mat tengdur varahóteli er sjálfstæður viðbótarkostnaður og helst í ferðakostnaði; hann er ekki felldur út með gistiverðinu.
- Dagatal og Í dag nota virka valda gistingu og nauðsynleg herbergi. Varabókanir og afbókaðar bókanir eru áfram aðgengilegar í gistiyfirliti, korti og ferðaveski með skýrri stöðu.
- Sjálfvirkur gististaður fyrir brottfararáætlun og kort er aðeins tekinn úr gistingu sem er í notkun. Séu mörg nauðsynleg herbergi í boði er ekki giskað á upphafsstað; notandi velur úr vistuðum stöðum. Fyrirliggjandi brottfararáætlun sem vísar á varabókun/afbókaða gistingu fær ábendingu um yfirferð í stað leiðsagnar frá röngu hóteli.
- Valin varabókun eða upprunaleg bókun með tengdum valkostum er varin gegn eyðingu sem myndi skilja tengingarnar eftir óleysanlegar. Hægt er að velja annan kost, breyta tengingum eða skrá afbókun.

### Prófanir og staðfestingar

- Notandi staðfesti fyrri breytingar á iPhone með myndum: dagsetningaviðvaranir, röðun opinna lesta og Í dag með tengdum miða. Það er ekki staðfesting á nýju breytingunum hér.
- `node --check` á aðalskrift standast. Stöðug HTML-auðkenni eru einstök.
- `node test-flow.cjs` standast áfram: fyrri dagsetninga- og tímabeltaflæði, opin ferð, vistun/enduropnun, heimflug, brottför kvöldið áður, tengdir miðar og upphafssýn.
- `node test-features.cjs` prófar raunverulegar vistunaraðgerðir forritsins í hermdu þjónustuumhverfi: nauðsynlegt barnaherbergi ásamt varabókun, nýjan gistivalkost, hlutverk við skörun, val og vistunarvillu, afbókun, gjald/endurgreiðslu, varðveislu fjárhagsgagna, gjalddaga og afbókunarfresti, óvissu um upphafshótel, nýtt skjal úr óvistaðri bókun, val eldra skjals, varðveislu innsláttar og skruns, aftengingu án eyðingar, vörn gegn yfirfærslu skjals annarrar bókunar og endurtilraun án tvískráningar. Erlend mynt með raunverulegri ISK-greiðslu er prófuð fyrir afbókunargjald.
- Kostnaðarglugginn sjálfur og föll fyrir reiknivél, þjórfé, skiptingu, útlagðan hluta, innslátt og drög voru borin saman við grunn og eru óbreytt. Fjárhagsyfirlit og val kostnaðarliða voru aðlöguð að gistivalkostum.
- Prófin nota tilbúnar bókanir og hermd þjónustuköll/gengi/skjalaupphleðslu. Engin raunveruleg innskráð vistun eða sending skjals var framkvæmd.

### Ólokið og næstu próf

- Nýja útgáfan er ekki sett á GitHub og hefur ekki verið prófuð á iPhone. Prófa þarf þar: eldri miða, nýtt PDF/mynd, aftur í óvistaða bókun, vistun og enduropnun; tvö nauðsynleg herbergi; tvö eða fleiri gistivalkosti; valkostaskipti; afbókunargjald og endurgreiðslu; gjalddaga og afbókunarfresti.
- Áminningar í þessari útgáfu birtast þegar appið er opið. Vöktun og tilkynningar þegar appið er lokað eru enn óútfærðar og þarf að taka sérstaklega fyrir.
- Ónettengd notkun ferðaveskis, almenn yfirferð gistináttagata og aðskilnaður daglegra reikninga frá dagskrá eru áfram óútfærð. Sjá samþykki og stöðu í fyrri köflum.
- Almenn skilyrði söluaðila eru ekki sótt sjálfkrafa. Notandi yfirfer og skráir afbókunar- og greiðslufresti úr sinni bókun.

## Fyrri viðbót 17. október — dagsetningar í tímalínu

Þessi afhending byggir á `i-dag-og-opnar-samgongur/index.html` og lagar tilkynnt ósamræmi. Eldri kaflar hér fyrir neðan geyma gildandi ákvarðanir og fyrri prófunarstöðu; þessi kafli hefur forgang um það sem breyttist nú.

- Sýnileg viðvörun er yfir ferðaleið, dagatali og Í dag þegar áfangastaðir liggja eftir skráða heimleið flugs fram og til baka. Textinn sýnir flug, dagsetningu og viðkomandi staði. Heimleið í einstökum fluglegg er ekki sjálfkrafa talin endalok allrar ferðar; viðvörunin biður um yfirferð.
- Áfangastaðir og bókanir með dagsetningar utan heildardaga ferðarinnar eru einnig merkt. Þetta sést jafnvel þótt notandi hafi áður samþykkt að vista undantekningu.
- Nýtt eða breytt ósamræmi milli heimflugs og síðari áfangastaða krefst skýrrar staðfestingar áður en flug eða áfangastaður vistast. Að hafna skrifar ekkert í gagnagrunn. Óbreytt ósamræmi krefst ekki endurtekinnar staðfestingar við óskylda vistun, en viðvörunin helst sýnileg.
- Fyrri heimild til að vista dagsetningar utan ferðar eftir viðvörun er varðveitt. Engin skráð dagsetning er leiðrétt sjálfvirkt.
- Eldri opnar samgöngufærslur án nýju áfangastaðatengingarinnar raðast eftir skráðum Frá/Til stöðum þegar þeir samsvara ótvírætt vistuðum áfangastöðum eða hafa vistaða auðkennis-tengingu. Við endurtekna samnefnda staði er ekki giskað á tengingu.
- Dregið áætlað dagabil nær frá brottför fyrri áfangastaðar til komu á næsta, ef það er í réttri röð. Dagabilið er merkt „Áætlað út frá áfangastöðum“. Það er aðeins notað til birtingar; raunverulegur brottfarardagur/klukka haldast opin.
- Línuskipti í opinni tímalínufærslu voru löguð svo leiðarheiti og stöðutexti renni ekki saman.

Prófanir: JavaScript-setningafræði og `node test-flow.cjs` standast. Prufudæmið hermir eftir myndinni: Kaupmannahöfn 15.–18. október, heimleið 18. október og Haag 19.–20. október. Það prófar viðvörun, leiðréttingu heimflugs, höfnun og samþykki nýs ósamræmis við vistun flugs, höfnun áfangastaðar sem veldur ósamræmi, röðun eldri opinnar lestar, óbreyttar dagsetningar og óvissu við samnefnda áfangastaði. Fyrri prufugagnaprófanir standast áfram. Kostnaðarútreikningar, kostnaðarvistun og Í dag-virknin voru borin saman við grunn og eru óbreytt.

Takmarkanir: Próf nota hermdan gagnagrunn. Engin ný iPhone- eða vafraprófun, raunveruleg innskráð vistun eða GitHub-uppfærsla hefur verið gerð hér. Notandinn þarf að yfirfara raunverulegar dagsetningar; kerfið veit ekki hvort leiðrétta eigi heimflugið eða Haag.

## Fyrri afhending — Í dag og opnar samgöngur

Grunnur: `kostnadur-fjoldi-hlid-vid-hlid/index.html`. Uppfært afrit: `index.html` í þessari möppu. Ekki hefur verið staðfest hvaða útgáfa er á GitHub. Engar breytingar hafa verið sendar í gagnagrunn eða á vefhýsingu í þessari vinnulotu.

Notandi samþykkti að byrja á úrbótum 1 og 3 úr vöruyfirferðinni:

1. Ferð innan skráðra ferðadaga opnast á „Í dag“, nema hún hafi verið merkt lokið/geymd. Dagatal velur daginn í stað upphafsdags. Framtíðarferðir og farnar ferðir opnast á ferðaleið. Viðmiðunardagur notar tímabelti gististaðar/áfangastaðar eða ferðar þegar það liggur fyrir.
2. „Næst á dagskrá“ velur næsta bókaða, tímasetta atriði með þekktu tímabelti. Það útilokar daglegar kostnaðarfærslur, opnar samgöngur og lokin atriði. Heimleið er metin sjálfstætt. Óþekkt tímabelti er ekki giskað til að reikna næsta atriði.
3. Næsta atriði sýnir skráðan tíma, tímabelti, bókunarnúmer þegar það er til, og skráða brottfararáætlun með leiðsögn. Hvorki ferðatími né mætingartími er tilbúinn sjálfvirkt. Tímar byggja á bókuninni; nýjustu flugupplýsingar eru áfram í flugvöktun.
4. Tengdir miðar/skjöl eru aðgengileg frá næsta atriði. Fleiri en eitt skjal, t.d. miðar beggja hjóna, fær hvert sinn hnapp. Netkrafa ferðaveskis er óbreytt.
5. Opnar lestar-, báta- og akstursferðir geta tengst frá/til áfangastöðum og/eða áætluðu dagabili. Þetta er valfrjálst. Heiti eitt nægir áfram.
6. Áætlað dagabil er sjálfstætt frá raunverulegri brottför. Án handvirks dagabils má staðsetja opna legginn í tímalínunni með brottfarardegi frá fyrri áfangastað eða komudegi á þann næsta. Það breytir ekki bókunargögnum. Dagabil og opnar klukkur eru skýrt merkt sem áætlun.
7. Opnar, ódagsettar samgöngur sem eiga við valinn dag birtast sér í dagatali og „Í dag“. Í dagatali eru þær þá ekki endurteknar í almenna óskipulagða listanum sama dag. Án samhengis eru þær áfram í almenna listanum.
8. „Ganga frá ferð“ opnar sömu færslu. Notandinn bætir við raunverulegum upplýsingum og velur Bókað. Áfangastaðatengingin varðveitist með færslunni en er ekki notuð til að færa bókaða ferð frá skráðum degi.
9. Dagabil þarf að vera innan ferðadaga og lokadagur ekki á undan upphafi. Eyðing tengds áfangastaðar krefst leiðréttingar við næstu vistun opinnar færslu.
10. Tímalína og dagatal haldast. Kostnaðargluggi og kostnaðarútreikningar eru óbreyttir.

## Samþykktar eldri reglur sem gilda áfram

- Íslenskt viðmót; varðveita útlit, virkni og gögn utan samþykktrar breytingar. „Alls staðar“ nær til allra sambærilegra staða.
- Bæði tímalína og dagatal, tengd með áfangastaða- og dagavali. Stöðug sjónræn hreyfing aðeins í „Næsti áfangastaður“; aðrir hlutar hreyfast mjúklega við aðgerðir.
- Kostnaðarröð: Flokkur → Tengist bókun? → Heiti → Upphæð og útreikningur. Einfalt heiti nægir.
- Kostnaðarflokkur er sjálfstæður, breytanlegur og sýnilegur. Bókun gefur forval þegar opnað er úr henni; almenn flýtileið man síðasta vistaða flokk í sama vafra. Val tengingar yfirskrifar ekki innslátt. Tengdur kostnaður telst aðeins einu sinni og sýnir emoji síns flokks við bókun.
- Nýskráning stofnar nýjan reikning. Eldri færsla er opnuð úr kostnaðaryfirliti eða við bókun til breytinga. Vistunarstaðfesting sýnir upphæð og greiðslustöðu.
- Þjórfé: ekkert, 5%, 10%, 12%, 15% eða eigin upphæð; reiknast fyrir skiptingu, engu bætt við ef innifalið. Reiknivél heldur áfram frá innslættri upphæð.
- „Fjöldi alls“ og „Okkar fjöldi“ hlið við hlið, líka í síma; tala velst við snertingu. Okkar fjöldi sjálfgefið tveir. Handvirkur okkar hluti er leyfður.
- Aðeins okkar hluti telst ferðakostnaður. Reikningur, þjórfé og skipting varðveitast. Greiðsla alls reikningsins fyrir hóp aðskilin frá okkar kostnaði og endurgreiðslukröfu. Móttekin endurgreiðsla og afturköllun breyta ekki okkar ferðakostnaði.
- „Hætta við“ lokar og geymir drög í sama vafra. Eldri drög má ekki yfirskrifa áður en valið er halda áfram eða henda. Drög teljast ekki kostnaður.
- Ófullgerð ISK-heild merkt bæði í ferð og kostnaðaryfirliti þegar gengi/ISK-greiðslu vantar. Innri vistunarupplýsingar mega ekki birtast sem athugasemdir.
- „Skoða tillögu að staðsetningu hótels“ opnar kort til yfirferðar; uppruni tillögu skýr og hún ekki talin staðfest hótelstaðsetning.

## Staða prófana og takmarkanir

- Notandi fór yfir fyrri breytingar á iPhone og tilkynnti engar villur. Ekki allir ferðahlutar voru prófaðir. Það samþykki er ekki prófun á þessari nýju afhendingu.
- JavaScript-setningafræði nýju útgáfunnar er prófuð með Node.
- `node test-flow.cjs`: prufugögn og hermt umhverfi prófa röðun í tímalínu, áfangastaðatengingu, dagabil og villur, vistun/enduropnun og breytingu sömu færslu úr opinni í bókaða, varðveislu annarra lýsigagna, Í dag-birtingu, heimleið, bæði skjöl hjóna og brottför kvöldið fyrir viðburð. Upphafssýn er prófuð fyrir ferð í gangi, framtíðarferð og farna ferð.
- Þjónustuköll í þessum prófum eru hermd. Þetta staðfestir ekki raunverulega gagnagrunnsvistun eða opnun einkaskjala í innskráðri lotu.
- Kóði kostnaðarútreikninga, þjórfjár, skiptingar, draga, uppgjörs, vistunar og enduropnunar kostnaðar, ásamt kostnaðarglugganum, var borinn saman við grunn og er óbreyttur.
- Engin vafra- eða iPhone-prófun hefur verið gerð á nýju breytingunni í þessari lotu. Stuðningur til vafraprófunar samkvæmt Sites-vinnuferli var ekki tiltækur.

## Eftir stendur

- Notendaprófun á iPhone: opna ferð í gangi, sjá rétt næsta atriði, opna miða beggja, fylgja leiðsögn, skrá opna lest/bát með samhengi, vista og enduropna, fullgera sama legg og yfirfara kostnað.
- Staðfesta nýjustu útgáfu á GitHub og raunverulega vistun/enduropnun gegn núverandi gagnagrunni eftir uppfærslu.
- Heildarprófun allra ferðahluta og samræmis við Sources-skjalið.
- Aðgangur án nets, yfirferð óþakinna gistinátta/flutninga og aðskilnaður daglegra reikninga frá dagskrá voru úrbótatillögur 2, 4 og 5. Þær eru ekki útfærðar eða samþykktar til framkvæmdar í þessari lotu.
- Varðandi eldra, stytt samtal skal ekki fylla í eyður með ágiskunum.
