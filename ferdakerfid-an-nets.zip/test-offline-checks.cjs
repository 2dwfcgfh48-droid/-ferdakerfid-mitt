const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
for(const file of ['index.html','offline.html']){const html=fs.readFileSync(__dirname+'/'+file,'utf8');const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(ids.length,new Set(ids).size,file+' has duplicate IDs');for(const m of html.matchAll(/<script[^>]+src="\.\/([^"]+)"/g))assert(fs.existsSync(__dirname+'/'+m[1]));const module=html.match(/<script type="module">([\s\S]*?)<\/script>/);if(module)new vm.Script(module[1].replace(/^import .*;$/gm,''));}
for(const file of ['offline-store.js','offline.js','sw.js'])new vm.Script(fs.readFileSync(__dirname+'/'+file,'utf8'));
assert(!/https?:\/\//.test(fs.readFileSync(__dirname+'/offline.html','utf8')),'Offline shell has an external dependency');
console.log('PASS: script syntax, unique IDs, production files present, no external offline shell dependencies.');
