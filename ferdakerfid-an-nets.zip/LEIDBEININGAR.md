# Ferð og miðar án nets

## Setja á GitHub

1. Afþjappaðu ZIP-pakkanum.
2. Settu þessar **fimm skrár saman** í sömu möppu á GitHub þar sem núverandi `index.html` er: `index.html`, `offline.html`, `offline.js`, `offline-store.js`, `sw.js`.
3. Skiptu eldri `index.html` út. Ekki breyta slóðinni eða flytja núverandi app. Hinar fjórar skrárnar eru nýjar fylgiskrár.
4. Vistaðu breytinguna á GitHub og bíddu eftir birtingu eins og áður. Ekki hlaða ZIP sjálfum upp sem staðgengli vefskránna.
5. Opnaðu appið á neti í símanum og endurhlaðaðu svo nýja útgáfan birtist.

Aðrar skrár pakkans eru leiðbeiningar, verkefnisskrá og próf; þær þarf ekki til að keyra appið. Engar breytingar þarf að gera í Supabase.

## Sækja og prófa

1. Opnaðu ferð á neti. Veldu **Sækja fyrir ferð**.
2. Veldu miða og skjöl sem eiga að fylgja. Ýttu á **Sækja valið** og bíddu eftir staðfestingu. Ef sókn mistekst helst fyrra afritið.
3. **Opna sótt afrit** sýnir hvað er í tækinu. Ósóttir miðar og vefslóðir eru sérstaklega merkt.
4. Lokaðu vefappinu, settu símann í flugham og opnaðu sömu vefslóð aftur í sama vafra. Lesarinn á að opnast og bjóða sóttu ferðina. Einnig má bókamerkja `offline.html` á sömu vefslóð.
5. Prófaðu bæði miðana, margra síðna PDF, heimilisfang, bókunarnúmer, dagaval og **Loka skjali**.
6. Þegar þú breytir ferð eða bætir við miða á neti skaltu sækja aftur. Afritið uppfærist ekki sjálfkrafa.

## Það sem þarf að vita

- Þetta er lesafrit í sama tæki og vafra. Hægt er að skoða og opna sótt skjöl, en ekki breyta bókunum án nets.
- Kort, leiðsögn, nýjustu flug-/veðurupplýsingar og ytri bókunarvefsíður þurfa net.
- Ekki útskrá þig eða hreinsa vafragögn áður en þú notar afritið: útskráning fjarlægir sóttar ferðir. Vafrinn getur einnig fjarlægt gögn við rýmiskort. Athugaðu afritið fyrir ferð.
- Notaðu sama vafra og sama uppsetningarham þegar þú sækir og prófar. Einkavöfrun og aðrir vafrar geta haft aðskilda eða tímabundna geymslu.
- PDF-birting fer eftir vafra. Ef hún bregst er hægt að opna vistuðu skrána í öðrum flipa eða hlaða henni niður undir Fleiri aðgerðir. Afritið af skránni þarf ekki gildan nettengil.
- Fjarlægja úr tækinu eyðir aðeins sótta afritinu; ferð og skjöl á netinu haldast.

## Staða prófana

Prufugagna- og hermipróf standast. Raunveruleg iPhone-/flughamprófun og hýst þjónustuvinnsla eru **ekki staðfest hér**. Pakkinn hefur ekki verið settur á GitHub.

Fyrir þróun: `npm ci --ignore-scripts` og `npm test`. Prófunarsöfnin eru eingöngu fyrir próf og þurfa ekki að fara á vefinn. Þegar lesaraskrám er breytt síðar þarf að uppfæra útgáfumerkið CACHE í `sw.js` svo eldri skyndiminni víki.
